JAutoShop — loja estática pronta para personalizar

1. Abre index.html no navegador para testar.
2. Substitui o WhatsApp +351000000000 no código pelo número real da loja.
3. Substitui email, preços, produtos, portes, prazos e políticas pelos dados reais.
4. Para vendas reais, configura atividade fiscal, faturação, IVA/OSS/IOSS quando aplicável, pagamentos e termos legais.
5. Publica index.html num alojamento estático (por exemplo, GitHub Pages, Netlify ou Cloudflare Pages).

NOTA: os produtos e preços no protótipo são exemplos de catálogo e não são ligações reais a anúncios do AliExpress.
